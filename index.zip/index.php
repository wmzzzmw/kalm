<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="utf-8">
	<title>Костюм из сериала Игра в кальмара</title>
	    <!-- Favicon -->
    <link rel="icon" href="https://squidgame-suit.items-world.com/img/products_new/7738.png" type="image/png">
    <link rel="shortcut icon" href="https://squidgame-suit.items-world.com/img/products_new/7738.png" type="image/png">

    <!-- OG -->
    <meta property="og:url" content="https://squidgame-suit.items-world.com/" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="Костюм из сериала Игра в кальмара" />
    <meta property="og:image" content="https://squidgame-suit.items-world.com/img/products_new/7738.png" />
    <meta property="og:image:width" content="150" />
    <meta property="og:image:height" content="150" />
    <meta property="og:site_name" content="Костюм из сериала Игра в кальмара" />
    <meta property="og:description" content="Костюм из сериала Игра в кальмара" />

    
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	
	<!-- CSS -->
	<link type="text/css" rel="stylesheet" href="files/squidgame_suit_1/css/style.css"/>

	<!-- JS -->
	<script src="files/_js/jquery-2.2.4.min.js" type="text/javascript"></script>

	<script type="text/javascript" src="files/_js/lastpack.js"></script>
	<script type="text/javascript" src="files/_js/validation.js"></script>

  	<script type="text/javascript" src="files/squidgame_suit_1/js/script.js"></script>
	<script type="text/javascript">$jsonData = {"product":{"id":7738,"name":"Костюм из сериала Игра в кальмара","title":"Костюм из сериала Игра в кальмара","short_description":"Костюм из сериала Игра в кальмара","full_description":"Костюм из сериала Игра в кальмара"},"prices":{"270":{"price":1700,"old_price":3400,"delivery_price":0,"tax_price":0,"upsale_price":0,"geo_key":"UA","name":"Україна","currency":"грн.","rate":0.37,"phone_template":"+38 067 927 25 74","address_template":"01024, г. Кiев, ул. Богомольца, д.5, кв.9","name_template":"Карпенко Ярослав Федорович","active":false},"271":{"price":1990,"old_price":3980,"delivery_price":0,"tax_price":0,"upsale_price":0,"geo_key":"RU","name":"Россия","currency":"руб.","rate":1,"phone_template":"+7 911 999-88-99","address_template":"135999, Москва, ул. Ленина, д.10, кв.5","name_template":"Петров Петр Петрович","active":true}},"lowPrice":{"year":"2021","month":"11","day":"16"}}; $landDir = 'squidgame_suit_1';</script>


</head>
<body>
<script type="text/javascript">
  var landing_notifiers = ptzvwkghwqlt Object(),
    price, currency, delivery_price;

  for (key in $jsonData.prices) {
    if ($jsonData.prices[key].active) {
      price = $jsonData.prices[key].price;
      currency = $jsonData.prices[key].currency;
      delivery_price = $jsonData.prices[key].price + $jsonData.prices[key].delivery_price;
    }
  }

  landing_notifiers.params = {
    city: "",
    landDir: "squidgame_suit_1",
    sex: "",
    multiply: "" || 0,
    no_price: "" || false,
    delay: ("" * 1000) || 12000,
    price: price || 0,
    currency: currency || "руб.",
    delivery_price: delivery_price,
    geoKey: "" || "RU",
    zdorov: "" || false
  };
</script>

<script type="text/javascript" src="files/_blocks/notificators/func.js@11"></script>

<script>
  var formIsSubmitted = false;
</script>

<script type="text/javascript" src="files/_blocks/notificators/unload_submit.js@7"></script>






























                                                                                                                                                                                              
            
<div class="xzvxvlooafrh">

    <header class="jgiukkfaszpowt yplceittxf">
        <h1 class="uukyzgachu">
            ТР<span style="display:none;">dac</span>ЕНД СЕ<span style="display:none;">qws</span>ЗОНА </h1>
        <div class="kvkhadyeci">
            <p class="wgxtucssjx">Костюмы из "И<span style="display:none;">pea</span>гра в кальмара" </p>
            <div class="tsqledysrxph qzeiuepcvyjydky">
                <b>50% скидка</b>
            </div>
            <img src="files/squidgame_suit_1/img/main.jpg" alt="">
        </div>
        <div class="oryqhgvpzs">
            <div class="ecrztecpjvt oqgjscrthocy">
                <div class="text">Обычная цена:</div>
                <div class="srfuqaaapww">
                    <span class="sihqdfphzkjef">3980</span> <span class="vjyltvpvruvwe">руб.<span style='display:none'>d4160dca96</span></span>
                </div>
            </div>
            <div class="ecrztecpjvt ptzvwkghwqlt  ">
                <div class="text">Цена сегодня:</div>
                <div class="srfuqaaapww">
                    <span class="dgjzroaeqsrdwl">1990</span> <span class="vjyltvpvruvwe">руб.</span>
                </div>
            </div>
        </div>
        <a href="#cat" class="ljjeqzcfvlsuihf">
            Вы<span style="display:none;">ooi</span>брать ко<span style="display:none;">foe</span>стюм            </a>
        <div class="rvhkjogearec">Осталось <b><span class="fuwxqukffxtqq"><span style='display:none'>631ddb747e</span></span></b> шт<span style="display:none;">dvp</span>ук по акции</div>
    </header>

    <section class="ztgvakfkghgous">
        <h2 class="frralrqkipfa"><span></span>Обнови гардероб!</h2>
        <p>
            Вы сп<span style="display:none;">pjr</span>росите у на<span style="display:none;">wew</span>с: "П<span style="display:none;">pzy</span>очему так де<span style="display:none;">ogt</span>шево?", мы от<span style="display:none;">gdv</span>ветим: пр<span style="display:none;">kkp</span>оизводители МЫ! По<span style="display:none;">eyv</span>купай в ро<span style="display:none;">auv</span>зницу по оп<span style="display:none;">jdg</span>товой це<span style="display:none;">ojg</span>не! Ст<span style="display:none;">hgt</span>ильные ко<span style="display:none;">ete</span>стюмы из сериала "И<span style="display:none;">pea</span>гра в кальмара" вы<span style="display:none;">epp</span>делят тв<span style="display:none;">wtf</span>ой об<span style="display:none;">gjj</span>раз, и ид<span style="display:none;">clh</span>еально по<span style="display:none;">euh</span>дойдут как для за<span style="display:none;">dai</span>нятия сп<span style="display:none;">axp</span>ортом, так и для ве<span style="display:none;">xar</span>черней пр<span style="display:none;">vyl</span>огулки. Данная
            мо<span style="display:none;">exj</span>дель сд<span style="display:none;">sfd</span>елана из 10<span style="display:none;">ihe</span>0% ит<span style="display:none;">irr</span>альянского не<span style="display:none;">tjs</span>опрена (с<span style="display:none;">wuy</span>куба). По<span style="display:none;">yzo</span>дчерки св<span style="display:none;">ohl</span>ою ун<span style="display:none;">uka</span>икальность с Be<span style="display:none;">odj</span>gmenov! </p>
    </section>

    <section class="cat" id="cat">
        <ul class="eqcihhqfrxgt">
            <li>
                <b>Размеры:</b> S/<span style="display:none;">uyk</span>M/L/XL/XXL </li>
            <li>
                <b>Состав:<span style='display:none'>d88388c330</span></b> 10<span style="display:none;">ihe</span>0% ит<span style="display:none;">vwx</span>альянский не<span style="display:none;">raj</span>опрен (с<span style="display:none;">oao</span>куба) </li>
        </ul>
        <div class="ppqiqreukrpzui">
            <div class="pyhuapyyfsxg ">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-3.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-4.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-1.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-2.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-5.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-6.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-7.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-10.jpg">
            </div>
            <div class="qzdywyskjwaqi">
                <h3>Игрок №4<span style="display:none;">szo</span>56 (С<span style="display:none;">twt</span>он Ги Ху<span style="display:none;">apf</span>н) </h3>
                <div class="agspulaykiupk qzdywyskjwaqi">
                    <div class="yvhlkjrtjyyylxh">
                            <span><span style='display:none'>3837205bc2<span style='display:none'>7f4e7ad6a4</span></span>50% </span>
                        <span1>
                            <p><span style='display:none'>258b5b1ec5</span>
                                <span class="sihqdfphzkjef">3980</span> <span class="vjyltvpvruvwe">руб.</span><span style='display:none'>4275573391</span></p>
                        </span1>
                    </div>
                    <div class="zqegcxickdoqw">
                        <span>Цена сегодня:</span>
                        <p>
                            <span class="dgjzroaeqsrdwl">1990</span> <span class="vjyltvpvruvwe">руб.</span>
                        </p>
                    </div>
                </div>
            </div>
            <a href="#order_form" class="ljjeqzcfvlsuihf">Оформить заказ со скидкой 50%<span style='display:none'>1924184f95</span></a></div>
    </section>

    <section class="cat" id="cat">
        <ul class="eqcihhqfrxgt">
            <li>
                <b>Размеры:</b> S/<span style="display:none;">uyk</span>M/L/XL/XXL </li>
            <li>
                <b><span style='display:none'>4a726f1cc5<span style='display:none'>9bb109ee68</span></span>Состав:</b> 10<span style="display:none;">ihe</span>0% ит<span style="display:none;">vwx</span>альянский не<span style="display:none;">raj</span>опрен (с<span style="display:none;">oao</span>куба) </li>
        </ul>

        <div class="ppqiqreukrpzui">
            <div class="pyhuapyyfsxg ">

                <img src="files/squidgame_suit_1/img/costumes-squid-067-1.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-067-2.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-067-3.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-067-4.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-067-5.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-067-6.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-067-7.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-067-8.jpg">
            </div>
            <div class="qzdywyskjwaqi">
                <h3>Игрок №0<span style="display:none;">wwr</span>67 (Сэ Бё<span style="display:none;">thx</span>к) - ун<span style="display:none;">lhf</span>исекс </h3>
                <div class="agspulaykiupk qzdywyskjwaqi">
                    <div class="yvhlkjrtjyyylxh">
                            <span>50% <span style='display:none'>cc8f7ea9cd</span></span>
                        <span1>
                            <p>
                                <span class="sihqdfphzkjef">3980</span> <span class="vjyltvpvruvwe">руб.</span>
                            </p>
                        </span1>
                    </div>
                    <div class="zqegcxickdoqw">
                        <span><span style='display:none'>38af12334a</span>Цена сегодня:</span>
                        <p>
                            <span class="dgjzroaeqsrdwl">1990</span> <span class="vjyltvpvruvwe">руб.</span>
                        <span style='display:none'>efc12331be</span></p>
                    </div>
                </div>
            </div><a href="#order_form" class="ljjeqzcfvlsuihf">Оформить заказ со скидкой 50%</a>
        </div>
    </section>

    <section class="cat" id="cat">
        <ul class="eqcihhqfrxgt">
            <li>
                <b>Размеры:</b> S/<span style="display:none;">uyk</span>M/L/XL/XXL </li>
            <li>
                <b>Состав:</b> 10<span style="display:none;">ihe</span>0% ит<span style="display:none;">vwx</span>альянский не<span style="display:none;">raj</span>опрен (с<span style="display:none;">oao</span>куба) </li>
        </ul>
        <div class="ppqiqreukrpzui">
            <div class="pyhuapyyfsxg ">
                <img src="files/squidgame_suit_1/img/costumes-squid-001-4.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-001-5.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-001-6.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-001-7.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-001-8.jpg">

            </div>
            <div class="qzdywyskjwaqi">
                <h3>Игрок №0<span style="display:none;">aah</span>01 (О Иль На<span style="display:none;">hos</span>м) </h3>
                <div class="agspulaykiupk qzdywyskjwaqi">
                    <div class="yvhlkjrtjyyylxh">
                            <span><span style='display:none'>84ad9ebbd5</span>50%<span style='display:none'>e1f7414231</span></span>
                        <span1>
                            <p>
                                <span class="sihqdfphzkjef">3980</span> <span class="vjyltvpvruvwe">руб.</span>
                            </p>
                        </span1>
                    </div>
                    <div class="zqegcxickdoqw">
                        <span>Цена сегодня:<span style='display:none'>0f877a7a33</span></span>
                        <p><span style='display:none'>4c31107b35</span>
                            <span class="dgjzroaeqsrdwl">1990</span> <span class="vjyltvpvruvwe">руб.</span>
                        </p>
                    </div>
                </div>
            </div>
            <a href="#order_form" class="ljjeqzcfvlsuihf">Оформить заказ со скидкой 50%<span style='display:none'>c78a335334</span></a>
        </div>
    </section>

    <section class="cat" id="cat">
        <ul class="eqcihhqfrxgt">
            <li>
                <b>Размеры:<span style='display:none'>bd1847c131</span></b> S/<span style="display:none;">uyk</span>M/L/XL/XXL </li>
            <li>
                <b>Состав:</b> 10<span style="display:none;">ihe</span>0% ит<span style="display:none;">vwx</span>альянский не<span style="display:none;">raj</span>опрен (с<span style="display:none;">oao</span>куба) </li>
        </ul>
        <div class="ppqiqreukrpzui">
            <div class="pyhuapyyfsxg ">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-8.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-9.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-456-11.jpg">
            </div>
            <div class="qzdywyskjwaqi">
                <h3>Игрок №4<span style="display:none;">szo</span>56 (С<span style="display:none;">twt</span>он Ги Ху<span style="display:none;">apf</span>н) </h3>
                <div class="agspulaykiupk qzdywyskjwaqi">
                    <div class="yvhlkjrtjyyylxh">
                            <span>50%</span>
                        <span1>
                            <p>
                                <span class="sihqdfphzkjef">3980</span> <span class="vjyltvpvruvwe">руб.<span style='display:none'>11c0729e81</span></span>
                            </p>
                        </span1>
                    </div>
                    <div class="zqegcxickdoqw">
                        <span>Цена сегодня:</span>
                        <p>
                            <span class="dgjzroaeqsrdwl">1990</span> <span class="vjyltvpvruvwe">руб.</span>
                        </p>
                    </div>
                </div>
            </div>
            <a href="#order_form" class="ljjeqzcfvlsuihf">Оформить заказ со скидкой 50%</a>
        </div>
    </section>

    <section class="cat" id="cat">
        <ul class="eqcihhqfrxgt">
            <li>
                <b>Размеры:<span style='display:none'>29e39f71db</span></b> S/<span style="display:none;">uyk</span>M/L/XL/XXL </li>
            <li>
                <b>Состав:</b> 10<span style="display:none;">ihe</span>0% ит<span style="display:none;">vwx</span>альянский не<span style="display:none;">raj</span>опрен (с<span style="display:none;">oao</span>куба) </li>
        </ul>
        <div class="ppqiqreukrpzui">
            <div class="pyhuapyyfsxg">
                <img src="files/squidgame_suit_1/img/costumes-squid-001-1.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-001-2.jpg">
                <img src="files/squidgame_suit_1/img/costumes-squid-001-3.jpg">
            </div>
            <div class="qzdywyskjwaqi">
                <h3>Игрок №0<span style="display:none;">aah</span>01 (О Иль На<span style="display:none;">hos</span>м) </h3>
                <div class="agspulaykiupk qzdywyskjwaqi">
                    <div class="yvhlkjrtjyyylxh">
                            <span>50%</span>
                        <span1>
                            <p>
                                <span class="sihqdfphzkjef">3980</span> <span class="vjyltvpvruvwe">руб.</span>
                            </p>
                        </span1>
                    </div>
                    <div class="zqegcxickdoqw">
                        <span><span style='display:none'>2108c58c48<span style='display:none'>3085eb85c1</span></span>Цена сегодня:<span style='display:none'>3adbf4ef05</span></span>
                        <p>
                            <span class="dgjzroaeqsrdwl">1990<span style='display:none'>3d40efdab8</span></span> <span class="vjyltvpvruvwe">руб.</span>
                        <span style='display:none'>bd1d2cbfe1</span></p>
                    </div>
                </div>
            </div>
            <a href="#order_form" class="ljjeqzcfvlsuihf">Оформить заказ со скидкой 50%<span style='display:none'>1b8250d700</span></a>
        </div>
    </section>

    <section class="ztgvakfkghgous">
        <h2 class="frralrqkipfa">Наши гарантии</h2>
        <p>Мы га<span style="display:none;">kyp</span>рантируем 10<span style="display:none;">ihe</span>0% об<span style="display:none;">pju</span>мен в сл<span style="display:none;">uco</span>учае,если вд<span style="display:none;">app</span>руг ра<span style="display:none;">gfj</span>змер вам не по<span style="display:none;">koi</span>дойдет,что ма<span style="display:none;">kta</span>ловероятно. Об<span style="display:none;">wgt</span>меняем на др<span style="display:none;">tsx</span>угой ра<span style="display:none;">gfj</span>змер или на др<span style="display:none;">tsx</span>угой то<span style="display:none;">kso</span>вар, при эт<span style="display:none;">pwr</span>ом ра<span style="display:none;">ifs</span>сходы за до<span style="display:none;">jkv</span>ставку оп<span style="display:none;">ste</span>лачиваем за св<span style="display:none;">qgk</span>ой сч<span style="display:none;">pjj</span>ет. В 20<span style="display:none;">juw</span>20 го<span style="display:none;">luz</span>ду мы от<span style="display:none;">god</span>шили бо<span style="display:none;">yru</span>лее 20<span style="display:none;">urq</span>.000 ко<span style="display:none;">hzj</span>стюмов из фильма
            джентельмены<span style='display:none'>ff3cc4821c</span></p>
    </section>

    <section class="">
        <div class="tlt">
            <h2 class="frralrqkipfa"><span>Как сделать</span><br> заказ?</h2>
        </div>
        <div class="ytiozfdggpvdrlo">
            <div class="koiuuksiuhqx">
                <div class="uqdcvuqyodzjlx">
                    <img src="files/squidgame_suit_1/img/order_steps__step1_icon.png" alt="">
                    <h4>Заявка</h4>
                    <p>Заполните фо<span style="display:none;">kaf</span>рму на сайте</p>
                </div>
            </div>
            <div class="koiuuksiuhqx">
                <div class="uqdcvuqyodzjlx">
                    <img src="files/squidgame_suit_1/img/order_steps__step2_icon.png" alt="">
                    <h4>Звонок</h4>
                    <p>Наш ме<span style="display:none;">hwe</span>неджер пе<span style="display:none;">elf</span>резвонит для ут<span style="display:none;">tad</span>очнения де<span style="display:none;">pjo</span>талей за<span style="display:none;">ypc</span>каза и по<span style="display:none;">ljd</span>может оп<span style="display:none;">hxy</span>ределиться с размером.</p>
                </div>
            </div>
            <div class="koiuuksiuhqx">
                <div class="uqdcvuqyodzjlx">
                    <img src="files/squidgame_suit_1/img/order_steps__step3_icon.png" alt="">
                    <h4>Отправка</h4>
                    <p>Доставляем ваш то<span style="display:none;">qup</span>вар в течение<br>1-2 дн<span style="display:none;">qdh</span>ей. Ст<span style="display:none;">odw</span>оимость до<span style="display:none;">xer</span>ставки ра<span style="display:none;">jdq</span>ссчитывается ин<span style="display:none;">zwe</span>дивидуально в за<span style="display:none;">uij</span>висимости от Ва<span style="display:none;">vef</span>шего местоположения</p>
                </div>
            </div>
            <div class="koiuuksiuhqx">
                <div class="uqdcvuqyodzjlx">
                    <img src="files/squidgame_suit_1/img/order_steps1__step4_image.png" alt="">
                    <h4>Получение</h4>
                    <p>Оплачиваете заказ при по<span style="display:none;">jyk</span>лучении в пу<span style="display:none;">xps</span>нкте вы<span style="display:none;">ekr</span>дачи за<span style="display:none;">ypc</span>каза сл<span style="display:none;">xot</span>ужбы СД<span style="display:none;">ocl</span>ЭК или на По<span style="display:none;">owa</span>чте Ро<span style="display:none;">ztg</span>ссии или на ру<span style="display:none;">jks</span>ки курьеру</p>
                </div>
            </div>
        </div>
    </section>

    <section class="jgiukkfaszpowt yplceittxf daskywervj">
        <h1 class="uukyzgachu">ТРЕНД ЭТ<span style="display:none;">hsh</span>ОГО СЕЗОНА</h1>
        <div class="kvkhadyeci">
            <p class="wgxtucssjx">Костюмы из "И<span style="display:none;">pea</span>гра в кальмара" </p>
            <div class="tsqledysrxph">
                <b>50% скидка</b>
            </div>
            <img src="files/squidgame_suit_1/img/main.jpg" alt="">
        </div>
        <div class="oryqhgvpzs">
            <div class="ecrztecpjvt oqgjscrthocy">
                <div class="text">Обычная цена:</div>
                <div class="srfuqaaapww">
                    <span class="sihqdfphzkjef">3980</span> <span class="vjyltvpvruvwe">руб.<span style='display:none'>fe3385b0c5</span></span>
                </div>
            </div>
            <div class="ecrztecpjvt ptzvwkghwqlt">
                <div class="text">Цена сегодня:</div>
                <div class="srfuqaaapww">
                    <span class="dgjzroaeqsrdwl">1990<span style='display:none'>28d2789ae3</span></span> <span class="vjyltvpvruvwe">руб.</span>
                </div>
            </div>
        </div>

        <form id="order_form" class="swgkdxdrrqfhio hcuywlptwqk" action="order.php" method="post" name="order-form">
<input type="hidden" name="sub1" value="<?php echo htmlspecialchars($_GET['utm_source']); ?>">
<input type="hidden" name="sub2" value="<?php echo htmlspecialchars($_GET['utm_medium']); ?>">
<input type="hidden" name="sub3" value="<?php echo htmlspecialchars($_GET['utm_campaign']); ?>">
<input type="hidden" name="sub4" value="<?php echo htmlspecialchars($_GET['utm_content']); ?>">
<input type="hidden" name="sub5" value="<?php echo htmlspecialchars($_GET['utm_term']); ?>">
<input type="hidden" name="fbpx" value="<?php echo htmlspecialchars($_GET['fbpx']); ?>">

                            <select name="country" id='country' class="ddetpwpeezoeag dyfuavrfsk ujlpwyziscfuuz">  <option value='270'>Україна</option>  <option value='271' selected="selected">Россия</option>                 </select>
                        <input type="hidden" name="address" value="">
            <input type="hidden" name="product_count" id="product_count" value="1">
            <input type="hidden" name="number_product" value="7738">
            <input type="hidden" name="split_test_id" 	value="0">
<input type="hidden" name="split_test" 		value="0">
<input type="hidden" name="split_test_host" value="squidgame-suit.items-world.com">
<input type="hidden" name="fchck"           value="4b6c62a60308d287d34dfddeaa281d144bb006a0">
<input type="hidden" name="ucfi" id="ucfi"  value="0">            <input class="fiiaorulaoiladz" type="text" name="name" placeholder="Введите Ваше имя" required="">
            <input class="fiiaorulaoiladz" type="tel" name="phone" placeholder="Введите Ваш телефон" required="">
            <button class="ljjeqzcfvlsuihf">Оформить заказ со скидкой 50%</button>
        </form>

        <div class="rvhkjogearec">Осталось <b><span style='display:none'>25432e0381</span><span class="fuwxqukffxtqq"></span></b></div><b>
        </b>
    </section>

    <footer class="gtpczagjhogqc">
        <div class="eiqwlywaep" style="text-align: center; margin: 0px auto; padding: 30px 0; font-size:15px">
            <div class="flpofstvphpwko">
                <img src="files/_blocks/copyright/img/rekv.png" style="display:block;margin:0 auto">

<div style="text-align: right"><img src="files/_blocks/copyright/img/1001transits.png" style="display: inline-block !important;" /></div><br>
                <a href="privacypolicy.html" target="_blank">Политика конфиденциальности</a>
            </div>
        </div>
    </footer>

</div>

	


<?php if (!empty($_GET['fbpx'])): ?><!-- Facebook Pixel Code --><script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version="2.0";n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window, document,"script","https://connect.facebook.net/en_US/fbevents.js");fbq("init", "<?php echo htmlspecialchars($_GET['fbpx']); ?>");fbq("track", "PageView");</script><noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?php echo htmlspecialchars($_GET['fbpx']); ?>&ev=PageView&noscript=1"/></noscript><!-- End Facebook Pixel Code --><?php endif; ?>
<center><a href="privacy-policy.html">Privacy policy</a> | <a href="terms.html">Terms and Conditions</a></center></body>
</html>




